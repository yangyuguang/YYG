package com.pami.listener;

public interface AppDownLineListener {

	void onDowLine();
}
