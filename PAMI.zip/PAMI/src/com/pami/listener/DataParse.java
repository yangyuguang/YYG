package com.pami.listener;

public interface DataParse {
	public void onParse(String result)throws Exception;
}
