package com.pami.bean;

import android.graphics.Bitmap;
import android.widget.ImageView;

/**
 *
 * Created by yangyuguang on 15/9/18.
 */
public class ImageBeanHolder {

    public Bitmap bitmap;
    public ImageView imageView;
    public String path;
}
