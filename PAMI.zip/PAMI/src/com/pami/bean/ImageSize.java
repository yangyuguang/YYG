package com.pami.bean;

/**
 * 图片大小的类
 * Created by yangyuguang on 15/9/18.
 */
public class ImageSize {

	public int width;
	public int height;
}
