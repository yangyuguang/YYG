
package com.pami.test;

public class Bean {

}
